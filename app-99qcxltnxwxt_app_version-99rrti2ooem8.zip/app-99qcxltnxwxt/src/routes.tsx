import Dashboard from './pages/Dashboard';
import JobTracker from './pages/JobTracker';
import ResumeHelper from './pages/ResumeHelper';
import About from './pages/About';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Dashboard',
    path: '/',
    element: <Dashboard />
  },
  {
    name: 'Job Tracker',
    path: '/tracker',
    element: <JobTracker />
  },
  {
    name: 'Resume Helper',
    path: '/resume',
    element: <ResumeHelper />
  },
  {
    name: 'About',
    path: '/about',
    element: <About />
  }
];

export default routes;
