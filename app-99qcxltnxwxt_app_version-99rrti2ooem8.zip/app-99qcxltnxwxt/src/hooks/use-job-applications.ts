import { useState, useEffect } from 'react';
import { supabase } from '@/db/supabase';
import type { JobApplication } from '@/types';
import { toast } from 'sonner';

export function useJobApplications() {
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchApplications = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await (supabase as any)
        .from('job_applications')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const transformed: JobApplication[] = (data || []).map((item: any) => ({
        id: item.id,
        companyName: item.company_name,
        jobTitle: item.job_title,
        applicationDate: item.application_date,
        status: item.status,
        notes: item.notes
      }));

      setApplications(transformed);
    } catch (error: any) {
      console.error('Error fetching applications:', error);
      toast.error('Failed to load applications');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const addApplication = async (app: Omit<JobApplication, 'id'>) => {
    try {
      const { data, error } = await (supabase as any)
        .from('job_applications')
        .insert([{
          company_name: app.companyName,
          job_title: app.jobTitle,
          application_date: app.applicationDate,
          status: app.status,
          notes: app.notes
        }])
        .select()
        .single();

      if (error) throw error;
      
      const resData = data as any;
      const newApp: JobApplication = {
        id: resData.id,
        companyName: resData.company_name,
        jobTitle: resData.job_title,
        applicationDate: resData.application_date,
        status: resData.status,
        notes: resData.notes
      };

      setApplications(prev => [newApp, ...prev]);
      toast.success('Application added successfully');
    } catch (error: any) {
      console.error('Error adding application:', error);
      toast.error('Failed to add application');
    }
  };

  const updateApplication = async (updatedApp: JobApplication) => {
    try {
      const { error } = await (supabase as any)
        .from('job_applications')
        .update({
          company_name: updatedApp.companyName,
          job_title: updatedApp.jobTitle,
          application_date: updatedApp.applicationDate,
          status: updatedApp.status,
          notes: updatedApp.notes
        })
        .eq('id', updatedApp.id);

      if (error) throw error;

      setApplications(prev =>
        prev.map(app => (app.id === updatedApp.id ? updatedApp : app))
      );
      toast.success('Application updated');
    } catch (error: any) {
      console.error('Error updating application:', error);
      toast.error('Failed to update application');
    }
  };

  const deleteApplication = async (id: string) => {
    try {
      const { error } = await (supabase as any)
        .from('job_applications')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setApplications(prev => prev.filter(app => app.id !== id));
      toast.success('Application deleted');
    } catch (error: any) {
      console.error('Error deleting application:', error);
      toast.error('Failed to delete application');
    }
  };

  return {
    applications,
    isLoading,
    addApplication,
    updateApplication,
    deleteApplication,
    refresh: fetchApplications
  };
}
