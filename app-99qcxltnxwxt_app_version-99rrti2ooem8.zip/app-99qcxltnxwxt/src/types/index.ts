export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export interface JobApplication {
  id: string;
  companyName: string;
  jobTitle: string;
  applicationDate: string;
  status: 'Applied' | 'Interview' | 'Offer' | 'Rejected';
  notes: string;
}

export type ApplicationStatus = JobApplication['status'];

