import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, ListTodo, FileText, Info, Menu, X, Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';

interface MainLayoutProps {
  children: React.ReactNode;
}

const APP_NAME = "Tairaverse";
const APP_ICON_URL = "https://miaoda-conversation-file.s3cdn.medo.dev/user-978bl67z9u68/conv-99qcxltnxwxs/20260130/file-99qvscgetf5s.png";

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Job Tracker', href: '/tracker', icon: ListTodo },
  { name: 'Resume Helper', href: '/resume', icon: FileText },
  { name: 'About', href: '/about', icon: Info },
];

export default function MainLayout({ children }: MainLayoutProps) {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const NavContent = () => (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 px-6 py-8">
        <img src={APP_ICON_URL} alt="Logo" className="w-10 h-10 rounded-xl shadow-lg shadow-primary/20" />
        <span className="text-2xl font-bold tracking-tight gradient-text">{APP_NAME}</span>
      </div>
      <nav className="flex-1 px-4 space-y-1">
        {navigation.map((item) => {
          const isActive = location.pathname === item.href;
          return (
            <Link
              key={item.name}
              to={item.href}
              className={cn(
                "flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200",
                isActive 
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" 
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <item.icon className={cn("w-5 h-5", isActive ? "text-primary-foreground" : "text-muted-foreground")} />
              {item.name}
            </Link>
          );
        })}
      </nav>
      <div className="p-4 mt-auto">
        <div className="bg-primary/5 rounded-2xl p-6 border border-primary/10">
          <Rocket className="w-8 h-8 text-primary mb-3" />
          <p className="text-sm font-semibold text-foreground mb-1">Boost your career</p>
          <p className="text-xs text-muted-foreground mb-4">Keep tracking to see your progress!</p>
          <Button variant="default" size="sm" className="w-full" asChild>
            <Link to="/tracker">Track Now</Link>
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-72 flex-col fixed inset-y-0 border-r bg-card shadow-sm">
        <NavContent />
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:pl-72">
        {/* Mobile Header */}
        <header className="lg:hidden sticky top-0 z-40 flex h-16 shrink-0 items-center justify-between border-b bg-background/80 backdrop-blur-md px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <img src={APP_ICON_URL} alt="Logo" className="w-8 h-8 rounded-lg" />
            <span className="font-bold text-xl gradient-text">{APP_NAME}</span>
          </div>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-72">
              <NavContent />
            </SheetContent>
          </Sheet>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <div className="mx-auto max-w-7xl animate-fade-in">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
