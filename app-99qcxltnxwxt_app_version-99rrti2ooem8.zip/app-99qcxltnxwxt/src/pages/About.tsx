import { Card, CardContent } from "@/components/ui/card";
import { Github, Globe, Linkedin, Mail, Twitter } from "lucide-react";

const DEVELOPER_PIC_URL = "https://miaoda-conversation-file.s3cdn.medo.dev/user-978bl67z9u68/conv-99qcxltnxwxs/20260130/file-99qw9g21z2f4.jpg";

export default function About() {
  return (
    <div className="max-w-3xl mx-auto space-y-12 py-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl gradient-text">
          About Tairaverse
        </h1>
        <p className="text-xl text-muted-foreground">
          Empowering job seekers to organize their future, one application at a time.
        </p>
      </div>

      <Card className="border-none shadow-sm overflow-hidden bg-primary/5">
        <CardContent className="p-8">
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">The Vision</h2>
            <p className="text-muted-foreground leading-relaxed">
              Applying for jobs can be overwhelming. Keeping track of spreadsheets, notes, and various portals is a job in itself. Tairaverse was created to simplify this process, providing a clean, modern interface for students and fresh graduates to manage their career journey.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
              <div className="space-y-2">
                <h3 className="font-bold">Simple Tracking</h3>
                <p className="text-sm text-muted-foreground">Quickly add and monitor the status of every application from a single dashboard.</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-bold">Resume Optimization</h3>
                <p className="text-sm text-muted-foreground">Tools designed to help you align your skills with job requirements effectively.</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-8">
        <h2 className="text-2xl font-bold text-center">Meet the Creator</h2>
        <Card className="border-none shadow-md overflow-hidden bg-card">
          <CardContent className="p-0">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/3">
                <img 
                  src={DEVELOPER_PIC_URL} 
                  alt="Developer" 
                  className="w-full h-full object-cover aspect-square md:aspect-auto"
                />
              </div>
              <div className="md:w-2/3 p-8 flex flex-col justify-center space-y-4">
                <div>
                  <h3 className="text-2xl font-bold">Tairaverse Developer</h3>
                  <p className="text-primary font-medium">Full Stack Developer & Career Enthusiast</p>
                </div>
                <p className="text-muted-foreground italic">
                  "I built Tairaverse because I believe everyone deserves a professional tool to help them land their dream job. Focus on the interview, let us handle the organization."
                </p>
                <div className="flex gap-4 pt-4">
                  <div className="p-2 bg-secondary rounded-full cursor-pointer hover:bg-primary/10 transition-colors">
                    <Github className="w-5 h-5 text-muted-foreground hover:text-primary" />
                  </div>
                  <div className="p-2 bg-secondary rounded-full cursor-pointer hover:bg-primary/10 transition-colors">
                    <Linkedin className="w-5 h-5 text-muted-foreground hover:text-primary" />
                  </div>
                  <div className="p-2 bg-secondary rounded-full cursor-pointer hover:bg-primary/10 transition-colors">
                    <Twitter className="w-5 h-5 text-muted-foreground hover:text-primary" />
                  </div>
                  <div className="p-2 bg-secondary rounded-full cursor-pointer hover:bg-primary/10 transition-colors">
                    <Mail className="w-5 h-5 text-muted-foreground hover:text-primary" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-center text-sm text-muted-foreground pt-8 border-t">
        <p>© 2026 Tairaverse. Built with ❤️ for the community.</p>
      </div>
    </div>
  );
}
