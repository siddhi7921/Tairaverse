import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Sparkles, 
  CheckCircle2, 
  Lightbulb, 
  FileSearch,
  ArrowRight,
  ClipboardCheck,
  Zap
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";

export default function ResumeHelper() {
  const [resume, setResume] = useState('');
  const [jobDesc, setJobDesc] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisDone, setAnalysisDone] = useState(false);

  const handleAnalyze = () => {
    if (!resume || !jobDesc) return;
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      setAnalysisDone(true);
    }, 2000);
  };

  const tips = [
    { title: "Quantify Achievements", desc: "Use numbers (e.g., 'Increased efficiency by 20%') instead of just listing duties." },
    { title: "Keyword Matching", desc: "Include specific skills mentioned in the job description to pass ATS filters." },
    { title: "Strong Action Verbs", desc: "Start bullet points with words like 'Developed', 'Managed', 'Engineered'." },
    { title: "Clean Formatting", desc: "Keep it simple and readable. Avoid complex tables or unusual fonts." },
  ];

  const suggestedKeywords = ["React", "TypeScript", "Agile", "Teamwork", "Problem Solving", "SaaS", "API Design", "Performance Optimization"];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Resume Helper</h1>
        <p className="text-muted-foreground mt-1">Optimize your resume for the job you want.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ClipboardCheck className="w-5 h-5 text-primary" />
                Your Inputs
              </CardTitle>
              <CardDescription>Paste your current resume and the target job description.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="resume">Paste Resume Content</Label>
                <Textarea 
                  id="resume" 
                  placeholder="Paste your resume text here..." 
                  className="min-h-[200px] bg-secondary/30 border-none focus-visible:ring-primary"
                  value={resume}
                  onChange={(e) => setResume(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="jd">Paste Job Description</Label>
                <Textarea 
                  id="jd" 
                  placeholder="Paste the job description here..." 
                  className="min-h-[200px] bg-secondary/30 border-none focus-visible:ring-primary"
                  value={jobDesc}
                  onChange={(e) => setJobDesc(e.target.value)}
                />
              </div>
              <Button 
                className="w-full" 
                onClick={handleAnalyze} 
                disabled={isAnalyzing || !resume || !jobDesc}
              >
                {isAnalyzing ? (
                  <>
                    <Zap className="w-4 h-4 mr-2 animate-pulse" />
                    Analyzing Skills...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Compare & Analyze
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {analysisDone ? (
            <Card className="border-none shadow-sm animate-fade-in bg-primary/5 border-primary/20 border">
              <CardHeader>
                <CardTitle className="text-lg font-bold flex items-center gap-2">
                  <FileSearch className="w-5 h-5 text-primary" />
                  Analysis Result
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm font-medium">
                    <span>Keyword Match Score</span>
                    <span className="text-primary">75%</span>
                  </div>
                  <Progress value={75} className="h-2" />
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-sm flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Missing Keywords
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {suggestedKeywords.slice(0, 5).map(word => (
                      <span key={word} className="px-3 py-1 bg-background rounded-full text-xs font-medium border border-border shadow-sm">
                        + {word}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-background/80 p-4 rounded-xl border border-border/50">
                  <p className="text-sm font-medium text-foreground">Next Steps:</p>
                  <ul className="mt-2 space-y-2 text-xs text-muted-foreground list-disc pl-4">
                    <li>Add 'Performance Optimization' to your skills section.</li>
                    <li>Quantify your experience with React.</li>
                    <li>Tailor your summary to mention SaaS experience.</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-amber-500" />
                  Resume Improvement Checklist
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {tips.map((tip, i) => (
                    <li key={i} className="flex gap-4">
                      <div className="bg-amber-50 h-8 w-8 rounded-full flex items-center justify-center shrink-0">
                        <span className="text-amber-600 font-bold text-xs">{i + 1}</span>
                      </div>
                      <div>
                        <p className="font-semibold text-sm">{tip.title}</p>
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                          {tip.desc}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          <Card className="border-none shadow-sm bg-secondary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Pro Tip</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed">
                Most big companies use <strong>ATS (Applicant Tracking Systems)</strong>. These systems scan your resume for keywords before a human ever sees it. Always tailor your resume for each specific job!
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
