import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useJobApplications } from "@/hooks/use-job-applications";
import { 
  Briefcase, 
  CalendarCheck, 
  Trophy, 
  XCircle, 
  TrendingUp,
  Clock
} from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "motion/react";

export default function Dashboard() {
  const { applications, isLoading } = useJobApplications();

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="space-y-2">
          <Skeleton className="h-10 w-64 bg-muted" />
          <Skeleton className="h-4 w-96 bg-muted" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 bg-muted rounded-xl" />)}
        </div>
        <div className="grid gap-6 md:grid-cols-7">
          <Skeleton className="md:col-span-4 h-[400px] bg-muted rounded-xl" />
          <Skeleton className="md:col-span-3 h-[400px] bg-muted rounded-xl" />
        </div>
      </div>
    );
  }

  const total = applications.length;
  const interviews = applications.filter(a => a.status === 'Interview').length;
  const offers = applications.filter(a => a.status === 'Offer').length;
  const rejected = applications.filter(a => a.status === 'Rejected').length;
  const applied = applications.filter(a => a.status === 'Applied').length;

  const statusData = [
    { name: 'Applied', value: applied, color: 'hsl(var(--primary))' },
    { name: 'Interview', value: interviews, color: '#f59e0b' },
    { name: 'Offer', value: offers, color: '#10b981' },
    { name: 'Rejected', value: rejected, color: '#ef4444' },
  ];

  const recentApps = [...applications].sort((a, b) => 
    new Date(b.applicationDate).getTime() - new Date(a.applicationDate).getTime()
  ).slice(0, 5);

  const stats = [
    { 
      label: "Total Applications", 
      value: total, 
      icon: Briefcase, 
      color: "text-blue-600",
      bg: "bg-blue-50"
    },
    { 
      label: "Interviews", 
      value: interviews, 
      icon: CalendarCheck, 
      color: "text-amber-600",
      bg: "bg-amber-50"
    },
    { 
      label: "Offers Received", 
      value: offers, 
      icon: Trophy, 
      color: "text-emerald-600",
      bg: "bg-emerald-50"
    },
    { 
      label: "Rejections", 
      value: rejected, 
      icon: XCircle, 
      color: "text-rose-600",
      bg: "bg-rose-50"
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Welcome back, Job Hunter! 🎯</h1>
        <p className="text-muted-foreground mt-2">Here's a summary of your job search progress.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="overflow-hidden border-none shadow-sm hover:shadow-md transition-shadow h-full">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                    <p className="text-3xl font-bold mt-1">{stat.value}</p>
                  </div>
                  <div className={`${stat.bg} p-3 rounded-xl`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-7">
        <Card className="md:col-span-4 border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Application Distribution
            </CardTitle>
            <CardDescription>Breakdown of your applications by status</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statusData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: 'hsl(var(--secondary))', opacity: 0.4 }}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="md:col-span-3 border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              Recent Activities
            </CardTitle>
            <CardDescription>Latest updates to your tracker</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentApps.length > 0 ? recentApps.map((app) => (
                <div key={app.id} className="flex items-start justify-between border-b border-border/50 pb-4 last:border-0 last:pb-0">
                  <div>
                    <p className="font-semibold text-sm">{app.companyName}</p>
                    <p className="text-xs text-muted-foreground">{app.jobTitle}</p>
                  </div>
                  <div className="text-right">
                    <span className={cn(
                      "inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium",
                      app.status === 'Offer' ? "bg-emerald-100 text-emerald-700" :
                      app.status === 'Interview' ? "bg-amber-100 text-amber-700" :
                      app.status === 'Rejected' ? "bg-rose-100 text-rose-700" :
                      "bg-blue-100 text-blue-700"
                    )}>
                      {app.status}
                    </span>
                    <p className="text-[10px] text-muted-foreground mt-1">{app.applicationDate}</p>
                  </div>
                </div>
              )) : (
                <div className="text-center py-8">
                  <p className="text-sm text-muted-foreground">No recent applications found.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
